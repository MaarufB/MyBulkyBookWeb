﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulkyBook.Utility
{
    public class StripeSettings
    {
        public static string? SecretKey {get; set;}
        public static string? PublishableKey { get; set;}
    }
}
